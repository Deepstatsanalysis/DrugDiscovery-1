#!/bin/bash
./program2.out $1
