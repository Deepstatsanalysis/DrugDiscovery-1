#!/bin/bash
./program1.out $1
